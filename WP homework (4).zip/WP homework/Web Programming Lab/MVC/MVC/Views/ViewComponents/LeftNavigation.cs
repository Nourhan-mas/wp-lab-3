﻿using Microsoft.AspNetCore.Mvc;
using mvc_Project.Models;
using System;
using System.Collections.Generic;

namespace mvc_Project.Views.ViewComponents
{
    public class LeftNavigationViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            var navigationLinks = new List<NavigationLink>
            {
                new NavigationLink { Text = "Home", Url = "/Home/Index" },
                new NavigationLink { Text = "Employees", Url = "/Employee/Index" },
                new NavigationLink { Text = "Privacy", Url = "/Home/Privacy" }
            };
            return View("Default", navigationLinks);
        }
    }
}
