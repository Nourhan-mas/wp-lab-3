﻿namespace mvc_Project.Models
{
        public class NavigationLink
        {
            public string Text { get; set; }
            public string Url { get; set; }
        }

}
